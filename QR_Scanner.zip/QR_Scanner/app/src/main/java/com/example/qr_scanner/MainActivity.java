package com.example.qr_scanner;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private static final String TAG = "UPI";
    private EditText pay_amount_edit;
    final int UPI_PAYMENT = 0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        pay_amount_edit = findViewById(R.id.payment_amount_edit);
//        Log.d("Tag", "onCreate: " + "Create");

        pay_amount_edit.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if ((event.getAction() == KeyEvent.ACTION_DOWN) &&
                        (keyCode == KeyEvent.KEYCODE_ENTER)){
                    IntentIntegrator intentIntegrator = new IntentIntegrator(MainActivity.this);
                    intentIntegrator.setOrientationLocked(true);
                    intentIntegrator.setCaptureActivity(Capture.class);
                    intentIntegrator.initiateScan();
                    Log.d(TAG, "onKey: "+ " Scan initiated");
                }
                return false;
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(requestCode == UPI_PAYMENT) {
            if ((RESULT_OK == resultCode) || (resultCode == 11)) {
                if (data != null) {
                    String response_text = data.getStringExtra("response");
//                    Log.e("UPI", "onActivityResult: " + response_text);
                    ArrayList<String> dataList = new ArrayList<>();
                    dataList.add(response_text);
                    upiPaymentDataOperation(dataList);
                } else {
//                    Log.e("UPI", "onActivityResult: " + "Return data is null");
                    ArrayList<String> dataList = new ArrayList<>();
                    dataList.add("nothing");
                    upiPaymentDataOperation(dataList);
                }
            } else {
                //when user cancels payment
                Log.e("UPI", "onActivityResult: " + "Return data is null");
                ArrayList<String> dataList = new ArrayList<>();
                dataList.add("nothing");
                upiPaymentDataOperation(dataList);
            }
        }

        if (data!=null && requestCode!=UPI_PAYMENT){
            //result of qr code
            IntentResult result = IntentIntegrator.parseActivityResult(requestCode, resultCode, data);
            if (result.getContents() != null){
                Log.d(TAG, "onActivityResult: "+ "After scan completes successfully");
                Toast.makeText(MainActivity.this, "Scan Successful",Toast.LENGTH_SHORT).show();
                Log.d(TAG, "onActivityResult: "+ result + "\n" + result.getContents());
                    upi_payment(result);

            }
        }
    }


    private void upi_payment(IntentResult result) {

        Intent upiPayIntent = new Intent(Intent.ACTION_VIEW);
        String amount = pay_amount_edit.getText().toString().trim();
//        Log.d(TAG, "onActivityResult: "+ amount);
        Uri uri = Uri.parse(result.getContents())
                .buildUpon()
                .appendQueryParameter("am", amount)
                .build();
        upiPayIntent.setData(uri);
//        Log.d(TAG, "onActivityResult: upi_pay_intent"+"\n uri " + uri);
        // will always show a dialog to user to choose an app
        Intent chooser = Intent.createChooser(upiPayIntent, "Pay with");
//        Log.d(TAG, "onActivityResult: chooser intent");
        // check if intent resolves
        if(chooser.resolveActivity(getPackageManager()) != null) {
            startActivityForResult(chooser, UPI_PAYMENT);
//            Log.d(TAG, "onActivityResult: "+ "success intent");
        } else {
            Toast.makeText(MainActivity.this,"No UPI app found, please install one to continue",Toast.LENGTH_SHORT).show();
//            Log.d(TAG, "onActivityResult: "+ "No upi app");
        }

    }

    private void upiPaymentDataOperation(ArrayList<String> data) {

        String str = data.get(0);
//            Log.e("UPIPAY", "upiPaymentDataOperation: "+str);
        String paymentCancel = "";
        if(str == null) str = "discard";
        String status = "";
        String approvalRefNo = "";
        String response[] = str.split("&");

        for (int i = 0; i < response.length; i++) {
            String equalStr[] = response[i].split("=");
            if(equalStr.length >= 2) {
                if (equalStr[0].toLowerCase().equals("Status".toLowerCase())) {
                    status = equalStr[1].toLowerCase();
                }
                else if (equalStr[0].toLowerCase().equals("ApprovalRefNo".toLowerCase()) || equalStr[0].toLowerCase().equals("txnRef".toLowerCase())) {
                    approvalRefNo = equalStr[1];
                }
            }
            else {
                paymentCancel = "Payment cancelled by user.";
            }
        }

        if (status.equals("success")) {
            //Code to handle successful transaction here.
            Toast.makeText(MainActivity.this, "Transaction successful.", Toast.LENGTH_SHORT).show();
            Log.e("UPI", "payment successfull: "+approvalRefNo);
        } else if("Payment cancelled by user.".equals(paymentCancel)) {
            Toast.makeText(MainActivity.this, "Payment cancelled by user.", Toast.LENGTH_SHORT).show();
            Log.e("UPI", "Cancelled by user: "+approvalRefNo);
        } else {
            Toast.makeText(MainActivity.this, "Transaction failed.Please try again", Toast.LENGTH_SHORT).show();
            Log.e("UPI", "failed payment: "+approvalRefNo);
        }
    }

}
