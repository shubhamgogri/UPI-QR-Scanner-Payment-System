package com.example.qr_scanner;

import com.journeyapps.barcodescanner.CaptureActivity;

public class Capture extends CaptureActivity {


}
